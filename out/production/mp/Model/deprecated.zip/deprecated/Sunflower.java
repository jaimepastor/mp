package Model;

public class Sunflower extends Crop{
    public Sunflower(String type,  double ht, int wn, int fn, int hc, int npp, int sc, double bp, int cb, int xp){
        super(type, ht, wn, fn, hc, npp, sc, bp, cb, xp);
    }
}
